<?php
require_once "autoload.php";
if (isset($_GET['controller'])){
    $nombreController = $_GET['controller']."Controller";
}
else{
    //Controlador per dedecto
    $nombreController = "mostrarController";
}
if (class_exists($nombreController)){
    $controlador = new $nombreController(); 
    if(isset($_GET['action'])){
        $action = $_GET['action'];
    }
    else{
        $action ="mostrarProfesores";
    }
    $controlador->$action();   
}else{

    echo "No existe el controlador";
}
?>