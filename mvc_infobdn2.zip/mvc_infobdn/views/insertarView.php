
<?php
//if ($_SESSION['role'] == 'admin') {
echo '<form action="../index.php?controller=insertar&action=InsertarDatos" method="post">
    ISBN
    <input type="text" name = "ID_CURSO">
    <input type="text" name = "NOMBRE">
    <input type="text" name = "DESCRIPCION">
    <input type="text" name = "HORAS">
    <input type="date" name = "F_INICIO">
    <input type="date" name = "F_FINAL">
    <input type="text" name = "PROFESOR">
    <br/>
  
    <input type = "submit" value="Añadir producto">
</form>';
//}
?>