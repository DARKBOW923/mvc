<?php
require_once 'database.php';
class verDatos extends database{

function mostrarCursos()
    {


        //add a search bar

       

        $query = "SELECT * FROM CURSO";

        //pdo query and print_r

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //print_r($result);
        //creates a table that prints the array content
        echo '<table class="centrar" border = 1px solid black>';
         echo '
         
             <th>ID_CURSO</th>
             <th> NOMBRE</th>
             <th>DESCRIPCION</th> 
             <th> HORAS </th> 
             <th> F_INICIO</th>
             <th> F_FINAL </th>
             <th> PROFESOR</th>
             <th> EDITAR</th>
             <th> ELIMINAR</th>
         
         ';
             
                 
         foreach ($result as $row ) {
                echo '
                     <tr>  
                         <td>' . $row['ID_CURSO'].'</td>
                         <td>' . $row['NOMBRE'] . '</td>
                         <td>' . $row['DESCRIPCION'] . '</td>
                         <td>' . $row['HORAS']. '</td>
                         <td>' . $row['F_INICIO']. '</td>
                         <td>' . $row['F_FINAL'] . '</td>
                         <td>' . $row['PROFESOR']. '</td>
                         <td><a href="modificacion_cursos.php?ID_CURSO='.$row['ID_CURSO']. '">editar</a></td>
                         <td><a href="eliminacion_cursos.php?ID_CURSO='.$row['ID_CURSO']. '">eliminar</a></td>
                         
                     </tr>';
                     
                 }
                 echo '</table>';
          
        }
      function mostrarProfesores(){
        $query = "SELECT * FROM PROFESOR";

        //pdo query and print_r

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        //print_r($result);
        //creates a table that prints the array content
        echo '<table class="centrar" border = 1px solid black>';
         echo '
         
             <th>DNI</th>
             <th> APELLIDOS</th>
             <th>T_ACADEMICO</th> 
             <th>FOTO</th> 
             <th>CONTRASENYA</th>
             <th>NOMBRE</th>
             <th>DESACTIVAR (ESTADO)</th>
         
         ';
             
                 
         foreach ($result as $row ) {
                echo '
                     <tr>  
                         <td>' . $row['DNI'].'</td>
                         <td>' . $row['APELLIDOS'] . '</td>
                         <td>' . $row['T_ACADEMICO'] . '</td>
                         <td>' . $row['FOTO']. '</td>
                         <td>' . $row['CONTRASENYA']. '</td>
                         <td>' . $row['NOMBRE'] . '</td>
                         <td>' . $row['DESACTIVAR']. '</td>
                         <td><a href="modificacion_cursos.php?ID_CURSO='.$row['DNI']. '">editar</a></td>
                         <td><a href="eliminacion_cursos.php?ID_CURSO='.$row['DNI']. '">eliminar</a></td>
                         
                     </tr>';
                     
                 }
                 echo '</table>'; 
        }  
        function mostrarAlumnos(){
            $query = "SELECT * FROM ALUMNOS";

            //pdo query and print_r
    
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo '<table class ="centrar" border = 1px solid black>';
echo '

    <th>ID_ALUMNO</th>
    <th> DNI</th>
    <th>NOMBRE</th> 
    <th> APELLIDO </th> 
    <th> FOTO</th>
    <th> CONTRASENYA </th>

';
    
        
foreach ($result as $row )  {
       echo '
            <tr>  
                <td>' . $row['ID_ALUMNO'].'</td>
                <td>' . $row['DNI'] . '</td>
                <td>' . $row['NOMBRE'] . '</td>
                <td>' . $row['APELLIDO']. '</td>
                <td>' . $row['FOTO']. '</td>
                <td>' . $row['CONTRASENYA'] . '</td>
                <td><a href="../administrador/modificacion_alumnos.php?ID_ALUMNO='.$row['ID_ALUMNO']. '">editar</a></td>
                <td><a href="../administrador/eliminacion_alumnos.php?ID_ALUMNO='.$row['ID_ALUMNO']. '">eliminar</a></td>
                
            </tr>';
            
        }
        echo '</table>';
        }
}

        ?>