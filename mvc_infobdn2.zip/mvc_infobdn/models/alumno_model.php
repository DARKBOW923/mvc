<?php
require_once "database.php";

class alumno_model extends database{

function desplegarAlumnosNormal(){
            $query = "SELECT * FROM ALUMNOS";

            //pdo query and print_r
    
            $stmt = $this->db->prepare($query);
           
                $stmt->execute();
                if( $stmt->num_rows ) {
                    return $stmt->fetchAll(PDO::FETCH_ASSOC);
                     } else {
                        return false;
                        }

                //this one doesn't show anything

            
            return $result;
            
    }
}
?>