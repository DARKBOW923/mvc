<?php
require_once 'database.php';

class profesorModel extends database{


function mostrarAlumnos(){
            $query = "SELECT * FROM ALUMNOS";

            //pdo query and print_r
    
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo '<table class ="centrar" border = 1px solid black>';
echo '

    <th>ID_ALUMNO</th>
    <th> DNI</th>
    <th>NOMBRE</th> 
    <th> APELLIDO </th> 
    <th> FOTO</th>
    <th> CONTRASENYA </th>

';
    
        
foreach ($result as $row )  {
       echo '
            <tr>  
                <td>' . $row['ID_ALUMNO'].'</td>
                <td>' . $row['DNI'] . '</td>
                <td>' . $row['NOMBRE'] . '</td>
                <td>' . $row['APELLIDO']. '</td>
                <td>' . $row['FOTO']. '</td>
                <td>' . $row['CONTRASENYA'] . '</td>
                <td><a href="../administrador/modificacion_alumnos.php?ID_ALUMNO='.$row['ID_ALUMNO']. '">editar</a></td>
                <td><a href="../administrador/eliminacion_alumnos.php?ID_ALUMNO='.$row['ID_ALUMNO']. '">eliminar</a></td>
                
            </tr>';
            
        }
        echo '</table>';
        }
}


        ?>