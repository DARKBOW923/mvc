<?php
class administrador{
    public function mostrarTodo(){
        echo "test";
        //aqui lo que hacemos es recoger los valores POST, creamos una instancia de insertarModel y luego 
        require_once "./models/mostrarModel.php";
        $verCosas = new verDatos();
        $verCosas->mostrarCursos();
        
    }
}
?>