<?php
class insertarController{
    public function InsertarDatos(){
        //aqui lo que hacemos es recoger los valores POST, creamos una instancia de insertarModel y luego 
        require_once "./models/insertarModel.php";
        $producto = new InsertarModel();
        $producto->getid_curso($_POST['ID_CURSO']);
        $producto->setid_curso($_POST['ID_CURSO']);
        $producto->getnombre($_POST['NOMBRE']);
        $producto->setnombre($_POST['NOMBRE']);
        $producto->getDescripcion($_POST['DESCRIPCION']);
        $producto->setDescripcion($_POST['DESCRIPCION']);
        $producto->getHoras($_POST['HORAS']);
        $producto->setHoras($_POST['HORAS']);
        $producto->getf_inicio($_POST['F_INICIO']);
        $producto->setf_inicio($_POST['F_INICIO']);
        $producto->getf_final($_POST['F_FINAL']);
        $producto->getf_final($_POST['F_FINAL']);
        $producto->getProfesor($_POST['PROFESOR']);
        $producto->setProfesor($_POST['PROFESOR']);
        $producto->conectar();
        echo "" . $producto->insertarLosDatos();
    }   
}
?>