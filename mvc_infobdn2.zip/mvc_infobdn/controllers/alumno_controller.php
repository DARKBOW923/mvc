<?php
class Alumno{
    function __construct() {
        echo $_GET['action'];
    }
    public function mostrarAlumnos(){
        //aqui lo que hacemos es recoger los valores POST, creamos una instancia de insertarModel y luego 
        require_once "../models/alumno_model.php";
        $alumno = new alumno_model();
        $mostrarTodos= $alumno->desplegarAlumnosNormal();
        var_dump($mostrarTodos);
        die;
        require_once "../views/verTodosLosAlumnos.php";
    }
}
?>